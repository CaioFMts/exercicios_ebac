language: pt

Funcionalidade: Cadastro e checkout
    Como usuario de sistema
    Eu quero realizar cadastro no sistema e prosseguir para o checkout
    Para que eu possa finalizar a compra do produto desejado

    Cenário: Cadastro de dados no sistema
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher os campos obrigatórios com informações válidas
        E clicar no botão "Cadastrar"
        Então o cadastro deve ser realizado com sucesso e uma mensagem de confirmação deve ser exibida

        Cenário: Cadastro de dados com informações incompletas (em branco)
        Dado que eu estou na página de cadastro do sistema
        Quando eu deixar algum campo obrigatório em branco  
        E clicar no botão "Cadastrar"
        Então uma mensagem de "Erro no cadastro! Preencha todos os campos obrigatórios." deve ser exibida, indicando que o cadastro não foi realizado com sucesso. E indicar quais campos faltam serem preenchidos com uma mensagem de "Campo obrigatório" e "*" ao lado do campo que não foi preenchido.

        Cenário: Cadastro de dados com formato inválido
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher algum campo obrigatório com informações em formato inválido (ex: email sem @)
        E clicar no botão "Cadastrar"
        Então uma mensagem de "Erro no cadastro! Email utilizado é invalido ou incorreto. Por favor, utilize um email válido." deve ser exibida, indicando que o cadastro não foi realizado com sucesso.

        Cenário: Cadastro de dados com email já cadastrado
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher o campo de email com um email que já está cadastrado no sistema
        E clicar no botão "Cadastrar"
        Então uma mensagem de "Erro no cadastro! Email já cadastrado. Por favor, utilize um email diferente." deve ser exibida, indicando que o cadastro não foi realizado com sucesso.
        
        Cenário: Cadastro de dados efetuado com sucesso e prosseguir para o checkout
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher todos os campos obrigatórios com informações válidas
        E clicar no botão "Cadastrar"
        Então o cadastro deve ser realizado com sucesso e uma mensagem de confirmação deve ser exibida, e eu devo ser redirecionado para a página de checkout para finalizar a compra do produto desejado.

        Cenário: Cadastro de dados efetuado com sucesso e prosseguir para o checkout com informações de endereço
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher todos os campos obrigatórios com informações válidas, incluindo informações de endereço
        E clicar no botão "Cadastrar"
        Então o cadastro deve ser realizado com sucesso e uma mensagem de confirmação deve ser exibida, e eu devo ser redirecionado para a página de checkout para finalizar a compra do produto desejado, com as informações de endereço preenchidas corretamente.

        Esquema do Cenário: Cadastro de multiplos dados no sistema
        Dado que eu estou na página de cadastro do sistema
        Quando eu preencher os campos obrigatórios com informações válidas
        E clicar no botão "Cadastrar"
        Então o cadastro deve ser realizado com sucesso e uma mensagem de confirmação deve ser exibida

        Exemplos:
            | Nome         | Sobrenome    | Email                  | Senha       | Endereço          | Cidade      | Estado     | CEP        | Mensagem de Confirmação |
            | João         | Silva        | joao.silva@email.com   | senha123    | Rua A, 123        | São Paulo   | SP         | 01000-000  | Cadastro realizado com sucesso! |
            | Maria        | Oliveira     | maria.oliveira@email.com | senha456    | Rua B, 456        | Rio de Janeiro | RJ         | 20000-000  | Cadastro realizado com sucesso! |
            | Carlos       | Santos       | carlos.santos@email.com  | senha789    | Rua C, 789        | Belo Horizonte | MG         | 30000-000  | Cadastro realizado com sucesso! |

            Esquema do Cenário: Cadastro com informações inválidas no sistema
            Dado que eu estou na página de cadastro do sistema
            Quando eu preencher os campos obrigatórios com informações inválidas
            E clicar no botão "Cadastrar"
            Então uma mensagem de erro deve ser exibida, indicando que o cadastro não foi realizado com sucesso

            Exemplos:
                | Nome         | Sobrenome    | Email                  | Senha       | Endereço          | Cidade      | Estado     | CEP        | Mensagem de Erro |
                | João         | Silva        | joao.silvaemail.com    | senha123    | Rua A, 123        | São Paulo   | SP         | 01000-000  | Erro no cadastro! Email utilizado é invalido ou incorreto. Por favor, utilize um email válido. |
                | Maria        | Oliveira     | maria.oliveiraemail.com | senha456    | Rua B, 456        | Rio de Janeiro | RJ         | 20000-000  | Erro no cadastro! Email utilizado é invalido ou incorreto. Por favor, utilize um email válido. |
                | Carlos       | Santos       | carlos.santosemail.com  | senha789    | Rua C, 789        | Belo Horizonte | MG         | 30000-000  | Erro no cadastro! Email utilizado é invalido ou incorreto. Por favor, utilize um email válido. |
            
            
            Esquema do Cenário: Cadastro com campos obrigatórios em branco no sistema
            Dado que eu estou na página de cadastro do sistema
            Quando eu deixar algum campo obrigatório em branco
            E clicar no botão "Cadastrar"
            Então uma mensagem de erro deve ser exibida, indicando que o cadastro não foi realizado com sucesso

            Exemplos:
                | Nome         | Sobrenome    | Email                  | Senha       | Endereço          | Cidade      | Estado     | CEP        | Mensagem de Erro |
                |              | Silva        |                          | senha123    | Rua A, 123        | São Paulo   | SP         | 01000-000  | Erro no cadastro! Por favor, preencha todos os campos obrigatórios. |
                | Maria        | Oliveira     |                           | senha456    | Rua B, 456        |                       |          |             | Erro no cadastro! Por favor, preencha todos os campos obrigatórios. |
                |              | Santos       | carlos.santos@email.com  | senha789    |                           | Belo Horizonte | MG         | 30000-000  | Erro no cadastro! Por favor, preencha todos os campos obrigatórios. |


            